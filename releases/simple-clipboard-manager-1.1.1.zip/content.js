let i=0;const c={autoSave:!0,showToasts:!0,skipPasswords:!0,excludedHosts:""};async function l(){try{const t=await chrome.storage.local.get("clipboard_settings");return{...c,...t.clipboard_settings||{}}}catch{return{...c}}}function m(){if(document.getElementById("clipboard-manager-toast-styles")||!document.head)return;const t=document.createElement("style");t.id="clipboard-manager-toast-styles",t.textContent=`
    @keyframes slideInUp {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes slideOutDown {
      from { opacity: 1; transform: translateY(0); }
      to { opacity: 0; transform: translateY(20px); }
    }
  `,document.head.appendChild(t)}async function p(t){var r;if(!(await l()).showToasts||!document.body)return;m(),(r=document.getElementById("clipboard-manager-toast"))==null||r.remove();const e=document.createElement("div");e.id="clipboard-manager-toast",e.style.cssText=`
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #3B82F6;
    color: white;
    padding: 12px 16px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    gap: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 500;
    animation: slideInUp 0.3s ease-out;
    pointer-events: none;
  `;const o=document.createElement("div");o.innerHTML=`
    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
    </svg>
  `,o.style.flexShrink="0";const s=document.createElement("span");s.textContent=t,e.appendChild(o),e.appendChild(s),document.body.appendChild(e),setTimeout(()=>{e.style.animation="slideOutDown 0.3s ease-out",setTimeout(()=>e.remove(),300)},2500)}function u(){var t;try{return!!((t=chrome==null?void 0:chrome.runtime)!=null&&t.id)}catch{return!1}}function f(t){if(!(t instanceof HTMLInputElement))return!1;const n=t.type.toLowerCase(),e=(t.autocomplete||"").toLowerCase();return n==="password"||e==="current-password"||e==="new-password"}function y(t,n){const e=t.toLowerCase();return n.split(/[\n,]/).map(o=>o.trim().toLowerCase().replace(/^https?:\/\//,"").split("/")[0]).filter(Boolean).some(o=>e===o||e.endsWith(`.${o}`))}function h(t){var o,s;const n=((o=t.clipboardData)==null?void 0:o.getData("text/plain"))||"";if(n.trim())return n;const e=document.activeElement;if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){const r=e.selectionStart??0,a=e.selectionEnd??0;if(a>r)return e.value.slice(r,a)}return((s=window.getSelection())==null?void 0:s.toString())||""}function d(t){const n=Date.now();n-i>500&&(p(t),i=n)}document.addEventListener("copy",t=>{const n=f(document.activeElement),e=h(t);setTimeout(async()=>{if(!u())return;const o=await l();if(!o.autoSave||o.skipPasswords&&n||y(window.location.hostname,o.excludedHosts))return;let s=e;if(!s.trim())try{s=await navigator.clipboard.readText()}catch{return}s.trim()&&chrome.runtime.sendMessage({type:"SAVE_CLIPBOARD",text:s},()=>{chrome.runtime.lastError})},100)});chrome.runtime.onMessage.addListener((t,n,e)=>!u()||!n?!1:(t.type==="CLIPBOARD_SAVED"?(d("Added to clipboard history"),e({success:!0})):t.type==="CLIPBOARD_UPDATED"&&(d("Already in history"),e({success:!0})),!0));
